const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, QueryCommand, GetCommand, PutCommand, UpdateCommand, ScanCommand, DeleteCommand } = require('@aws-sdk/lib-dynamodb');
const crypto = require('crypto');

const client = new DynamoDBClient({});
const dynamodb = DynamoDBDocumentClient.from(client);
const USERS_TABLE = 'supply_users';

// Simple password hashing (in production, use bcrypt)
function hashPassword(password) {
    return crypto.createHash('sha256').update(password).digest('hex');
}

// Generate JWT-like token (simplified)
function generateToken(user) {
    const payload = {
        userId: user.id,
        email: user.email,
        role: user.role,
        franchise_id: user.franchise_id || '',
        franchise_name: user.franchise_name || '',
        auditor_id: user.auditor_id || '',
        auditor_name: user.auditor_name || '',
        exp: Date.now() + 86400000 // 24 hours
    };
    return Buffer.from(JSON.stringify(payload)).toString('base64');
}

// Verify token
function verifyToken(token) {
    try {
        const payload = JSON.parse(Buffer.from(token, 'base64').toString('utf8'));
        if (payload.exp < Date.now()) {
            return null;
        }
        return payload;
    } catch {
        return null;
    }
}

// CORS headers
const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event));

    // Handle OPTIONS for CORS
    if (event.requestContext?.http?.method === 'OPTIONS' || event.httpMethod === 'OPTIONS') {
        return { statusCode: 200, headers, body: '' };
    }

    const httpMethod = event.requestContext?.http?.method || event.httpMethod;
    const path = event.rawPath || event.path;

    try {
        // POST /auth/login
        if (httpMethod === 'POST' && path.includes('/auth/login')) {
            const body = JSON.parse(event.body || '{}');
            const { email, password } = body;

            if (!email || !password) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: 'Email and password are required' })
                };
            }

            // Find user by email using GSI
            const result = await dynamodb.send(new QueryCommand({
                TableName: USERS_TABLE,
                IndexName: 'email-index',
                KeyConditionExpression: 'email = :email',
                ExpressionAttributeValues: { ':email': email }
            }));

            const user = result.Items?.[0];
            if (!user) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: 'Invalid email or password' })
                };
            }

            // Verify password (check both password_hash and password fields for compatibility)
            const hashedPassword = hashPassword(password);
            const storedPassword = user.password_hash || user.password;
            if (storedPassword !== hashedPassword) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: 'Invalid email or password' })
                };
            }

            // Generate token
            const token = generateToken(user);

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    token,
                    user: {
                        id: user.id,
                        email: user.email,
                        name: user.name,
                        role: user.role,
                        franchise_id: user.franchise_id || '',
                        franchise_name: user.franchise_name || '',
                        auditor_id: user.auditor_id || '',
                        auditor_name: user.auditor_name || ''
                    }
                })
            };
        }

        // GET /auth/me - Get current user
        if (httpMethod === 'GET' && path.includes('/auth/me')) {
            const authHeader = event.headers?.authorization || event.headers?.Authorization;
            if (!authHeader || !authHeader.startsWith('Bearer ')) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: 'No token provided' })
                };
            }

            const token = authHeader.replace('Bearer ', '');
            const payload = verifyToken(token);

            if (!payload) {
                return {
                    statusCode: 401,
                    headers,
                    body: JSON.stringify({ error: 'Invalid or expired token' })
                };
            }

            // Get user from database
            const result = await dynamodb.send(new GetCommand({
                TableName: USERS_TABLE,
                Key: { id: payload.userId }
            }));

            const user = result.Item;
            if (!user) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: 'User not found' })
                };
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({
                    id: user.id,
                    email: user.email,
                    name: user.name,
                    role: user.role,
                    franchise_id: user.franchise_id || '',
                    franchise_name: user.franchise_name || '',
                    auditor_id: user.auditor_id || '',
                    auditor_name: user.auditor_name || ''
                })
            };
        }

        return {
            statusCode: 404,
            headers,
            body: JSON.stringify({ error: 'Not found' })
        };

    } catch (error) {
        console.error('Error:', error);
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: 'Internal server error', details: error.message })
        };
    }
};
